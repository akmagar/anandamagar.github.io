
/* ********************************************************************************************************************** */
/*
 *                                      Enhancement Two (Algorithms and Data Structure)
 *                                      ------------------------------------------------
 * This is the updated version of the original project where I added extra functionality of entering the department using binary search algorithm
 * It is a simple "Online Shopping Cart" program in Java that takes two items and prints the total cost
 * This program prompts the users to enter the department number for choosing the department they desire
 * After user inputs the department number, they are directed to the chosen department
 * Then they can enter up to two items along with their name, price, and quantity after which the total cost is calculated and printed 
 * 
 * @author Ananda Magar
 */
/* *********************************************************************************************************************** */

/*
 * This is a ShoppingCartPrinter class that contains contains main() method
 */

import java.util.Scanner;
public class ShoppingCartPrinter {
   public static void main(String[] args) {
		  //Creating an object of BinaryClass
		  BinarySearch obj = new BinarySearch();

		  //Creating a sorted array
		  int[] array = { 1, 2, 3, 4 };
		  int n = array.length;

		  //Getting input from user for element to be searched
		  Scanner scnr1 = new Scanner(System.in);

		  System.out.println("Department number          Department");
		  System.out.println("-------------------------------------");
		  System.out.println("1                          Clothes");
		  System.out.println("2                          Toys");
		  System.out.println("3                          Electronics");
		  System.out.println("4                          Foods");
		  
		  System.out.println(" ");
		  System.out.println("Enter department number to choose department");

		  //Element to be searched
		  int element = scnr1.nextInt();
		  
		  System.out.println(" ");

		  //Calling the binary search method and passing arguments: array, element, index of first and last element
		  int result = obj.binarySearch(array, element, 0, n - 1);
		   
		  //Printing "You are in Clothes department" if the result equals 0
		  if(result == 0){
		      System.out.println("You are in Clothes department");
		  }
		  //Printing "You are in Toys department" if the result equals 1
		  else if(result == 1){
		      System.out.println("You are in Toys department");
		  }
		  //Printing "You are in Electronics department" if the result equals 2
		  else if(result == 2){
		      System.out.println("You are in Electronics department");
		  }
		  //Printing "You are in Foods department" if the result equals 3
		  else if(result == 3) {
		      System.out.println("You are in Foods department");
		  }
		  //Exiting the system if the result doesn't match the above specified numbers
		  else {
		      System.exit(0);
		  }

		  System.out.println(" ");
	      
		  //Getting user input for item name, item price, and item quantity
	      Scanner scnr2 = new Scanner(System.in);

	      String productName = "";
	      int productPrice = 0;
	      int productQuantity = 0;
	      int cartTotal = 0;
	  
	      ItemToPurchase item1 = new ItemToPurchase();
	      ItemToPurchase item2 = new ItemToPurchase();
	      
	      //Getting item 1 details from user, creating ItemPurchase object
	      System.out.println("Item 1");
	      System.out.println("---------------------");
	      System.out.println("Enter the item name: ");
	      productName = scnr2.nextLine(); 

	      System.out.println("Enter the item price: ");
	      productPrice = scnr2.nextInt(); 
	      
	      System.out.println("Enter the item quantity: ");
	      productQuantity = scnr2.nextInt();
	      
	      //Setting name, price, and quantity for item1
	      item1.setName(productName);
	      item1.setPrice(productPrice);
	      item1.setQuantity(productQuantity);
	      
	      //Calling scnr2.nextLine to allow user to input new String
	      scnr2.nextLine();
	      
	      //Getting item 2 details from user, creating ItemPurchase object
	      System.out.println("\nItem 2");
	      System.out.println("---------------------");
	      System.out.println("Enter the item name: ");
	      productName = scnr2.nextLine(); 
	      
	      System.out.println("Enter the item price: ");
	      productPrice = scnr2.nextInt(); 
	      
	      System.out.println("Enter the item quantity: ");
	      productQuantity = scnr2.nextInt();
	      
	      //Setting name, price, and quantity for item2
	      item2.setName(productName);
	      item2.setPrice(productPrice);
	      item2.setQuantity(productQuantity);
	      
	      //Calculating the sum of the cost of two items
	      cartTotal = (item1.getPrice() * item1.getQuantity()) + (item2.getPrice() * item2.getQuantity());      
	      //Printing TOTAL COST
	      System.out.println("\nTOTAL COST");
	      System.out.println("****************************************");
	      
	      //Getting and printing item 1 information
	      System.out.println(item1.getQuantity() + " " + item1.getName() + " " + " @ " + "$" + item1.getPrice() + " each " + " = $" + (item1.getPrice() * item1.getQuantity()));
	      
	      
	      //Getting and printing item two information
	      System.out.println(item2.getQuantity() + " " + item2.getName() + " "	  + " @ " + "$" + item2.getPrice() +  " each " + " = $" + (item2.getPrice() * item2.getQuantity()));
	      System.out.println("----------------------------------------");
	      
	      //Printing Total output
	      System.out.println("Total: $" + cartTotal);
	      
	      return;
	   }
	}