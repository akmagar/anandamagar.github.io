/*
 * This is a BinarySearch class that is created to search the elements in the array
 * This searches for the user entered number based on the index of an searched element in an Integer Type Array
 * 
 * @author Ananda Magar
 */

// Creating a Binary Search to search for the elements in an array
public class BinarySearch {
  int binarySearch(int array[], int element, int low, int high) {

    // Repeating until the pointers low and high meet each other
    while (low <= high) {

      // Getting the index of mid element
      int mid = low + (high - low) / 2;

      // If the element to be searched is the mid element
      if (array[mid] == element)
        return mid;

      // Searching only the left side of mid if the element is less than the mid element
      if (array[mid] < element)
        low = mid + 1;

      // Searching only the right side of mid if the element is greater than the mid element
      else
        high = mid - 1;
    }

    return -1;
  }
}