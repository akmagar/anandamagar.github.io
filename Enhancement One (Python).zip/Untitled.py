#!/usr/bin/env python
# coding: utf-8

# In[2]:


####################################################################################################################################
#                                        Enhancement One: Software Design and Engineering
#                                        ------------------------------------------------
# This is the updated version of the "Online Shopping Cart (Java)" project translated in Python
# Similar to the original project in Java, this project in Python does takes two items' names, prices, and quantities from the users
# Then calculates and prints the total costs of the two entered items

# author: Ananda Magar
####################################################################################################################################

#Creating a class ItemToPurchase
class ItemToPurchase:
    def __init__(self, item_name = 'none', item_price = 0, item_quantity = 0):
        self.item_name = item_name
        self.item_price = item_price
        self.item_quantity = item_quantity
        
#Defining a main function            
def main():
    print('Item 1')
    #Getting item 1 details from user
    item1_name = str(input('Enter the item name:\n'))
    item1_price = int(input('Enter the item price:\n'))
    item1_quantity = int(input('Enter the item quantity:\n'))
    
    item1 = ItemToPurchase()
    item1.item_name = item1_name
    item1.item_price = item1_price
    item1.item_quantity = item1_quantity
    
    print('Item 2')
    #Getting item 2 details from user
    item2_name = str(input('Enter the item name:\n'))
    item2_price = int(input('Enter the item price:\n'))
    item2_quantity = int(input('Enter the item quantity:\n'))
    
    item2 = ItemToPurchase()
    item2.item_name = item2_name
    item2.item_price = item2_price
    item2.item_quantity = item2_quantity

    #Calculating the sum of the costs of two items
    cartTotal = (item1.item_price * item1.item_quantity) + (item2.item_price * item2.item_quantity)

    #Printing Total Cost
    print('\nTOTAL COST')
    #Printing item 1 information
    print(item1.item_name,  item1.item_quantity, '@', '$%d' %(item1.item_price), '= $%d' %(item1.item_price * item1.item_quantity))
    #Printing item 2 information
    print(item2.item_name,  item2.item_quantity, '@', '$%d' %(item2.item_price), '= $%d' %(item2.item_price * item2.item_quantity))
    print()
    #Printing Total output
    print('Total: $%d' %(cartTotal))

main()


# In[ ]:




