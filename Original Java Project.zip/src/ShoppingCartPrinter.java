import java.util.Scanner;
public class ShoppingCartPrinter {
   public static void main(String[] args) {
	  //Creating a scanner instance
      Scanner scnr = new Scanner(System.in);
      String productName = "";
      int productPrice = 0;
      int productQuantity = 0;
      int cartTotal = 0;
  
      ItemToPurchase item1 = new ItemToPurchase();
      ItemToPurchase item2 = new ItemToPurchase();

      // Getting item 1 details from user
      System.out.println("Item 1");
      System.out.println("Enter the item name: ");
      productName = scnr.nextLine(); 

      System.out.println("Enter the item price: ");
      productPrice = scnr.nextInt(); 
      
      System.out.println("Enter the item quantity: ");
      productQuantity = scnr.nextInt();
      
      // Setting name, price, and quantity for item1
      item1.setName(productName);
      item1.setPrice(productPrice);
      item1.setQuantity(productQuantity);
      
      // Calling scnr.nextLine to allow user to input new String
      scnr.nextLine();
      
      // Getting item 2 details from user
      System.out.println("\nItem 2");
      System.out.println("Enter the item name: ");
      productName = scnr.nextLine(); 
      
      System.out.println("Enter the item price: ");
      productPrice = scnr.nextInt(); 
      
      System.out.println("Enter the item quantity: ");
      productQuantity = scnr.nextInt();
      
      // Setting name, price, and quantity for item2
      item2.setName(productName);
      item2.setPrice(productPrice);
      item2.setQuantity(productQuantity);
      
      // Calculating the sum of the cost of two items
      cartTotal = (item1.getPrice() * item1.getQuantity()) + (item2.getPrice() * item2.getQuantity());
      
      // Printing TOTAL COST
      System.out.println("\nTOTAL COST");
      
      // Getting and printing item 1 information
      System.out.println(item1.getName() + " "	  + item1.getQuantity() + " @ " + "$" + item1.getPrice() + " = $" + (item1.getPrice() * item1.getQuantity()));
      
      // Getting and printing item two information
      System.out.println(item2.getName() + " "	  + item2.getQuantity() + " @ " + "$" + item2.getPrice() + " = $" + (item2.getPrice() * item2.getQuantity()));
      
      // Printing Total output
      System.out.println("\nTotal: $" + cartTotal);
      
      return;
   }
}