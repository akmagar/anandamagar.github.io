public class ItemToPurchase {
   //Private fields - itemName, itemPrice, and itemQuanity
	private String itemName;
	private int itemPrice;
	private int itemQuantity;
   // Default Constructor
   // Initializing itemName to "none", itemPrice to 0, and itemQuantity to 0
	public ItemToPurchase() {
	itemName = "none";
	itemPrice = 0;
	itemQuantity = 0;
	return;
	}
    
   // Using public member methods (mutators & accessors)
	//setName() & getName() 
	public String getName(){
		return itemName;
	}
	public void setName(String itemName) {
		this.itemName = itemName;
	}
	
	//setPrice() & getPrice() 
	public int getPrice() {
		return itemPrice;
	}
	public void setPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	
	//setQuantity() & getQuantity() 
	public int getQuantity() {
		return itemQuantity;
	}
	public void setQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	
   
   //Printing item to purchase
   
   public void printItemPurchase() {
      System.out.println(itemQuantity + " " + itemName + " $" + itemPrice +  
                         " = $" + (itemPrice * itemQuantity));
   }

}
